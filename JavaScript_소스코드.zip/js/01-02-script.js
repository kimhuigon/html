function change() {
  document.getElementById("demo").innerHTML = "change";
}