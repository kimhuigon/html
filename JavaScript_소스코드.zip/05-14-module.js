export function plus() {
  return 2 + 1;
}