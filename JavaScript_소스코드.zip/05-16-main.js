import func from './05-16-module.js'
console.log(func());

import { default as func2 } from './05-16-module.js'
console.log(func2());