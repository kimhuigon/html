import { plus } from './05-14-module.js';
console.log(plus());