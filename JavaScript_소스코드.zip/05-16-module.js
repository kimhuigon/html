export default function() {
  return 'Default!'
}